from gpiozero import LightSensor, LED
from signal import pause

sensor = LightSensor(27)
led = LED(17)

sensor.when_dark = led.on
if sensor.wait_for_light():
    print("It's light!")
sensor.when_light = led.off
if sensor.wait_for_dark():
    print("It's dark!")

pause()
