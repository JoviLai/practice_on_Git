from gpiozero import LEDBarGraph
from time import sleep

graph = LEDBarGraph(17, 27, 22, 5, 6, pwm=True)

graph.value = 2/10
print("2/10 = (1, 0, 0, 0, 0)")
sleep(0.5)
graph.value = 5/10  
print("5/10 = (1, 1, 0.5, 0, 0)")
sleep(0.5)
graph.value = 7/10 
print("7/10 = (1, 1, 1, 0.5, 0)")
sleep(0.5)
graph.value = -9/10  
print("-9/10 = (0.5, 1, 1, 1, 1)")
sleep(0.5)
graph.value = -6/10  
print("-6/10 = (0, 0, 1, 1, 1)")
sleep(0.5)
graph.value = -3/10  
print("-3/10 = (0, 0, 0, 0.5, 1)")
sleep(0.5)
graph.value = 0
print("0 = (0, 0, 0, 0, 0)")
