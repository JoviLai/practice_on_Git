from gpiozero import LEDBarGraph, MCP3008
from signal import pause
from time import sleep

graph = LEDBarGraph(17, 27, 22, 5, pwm=True)
pot = MCP3008(channel=0)
graph.source = pot.values
sleep(0.5)
print("GPIO17  = %f"%graph[0].value)
print("GPIO27  = %f"%graph[1].value)
print("GPIO22  = %f"%graph[2].value)
print("GPIO5  = %f"%graph[3].value)

pause()
