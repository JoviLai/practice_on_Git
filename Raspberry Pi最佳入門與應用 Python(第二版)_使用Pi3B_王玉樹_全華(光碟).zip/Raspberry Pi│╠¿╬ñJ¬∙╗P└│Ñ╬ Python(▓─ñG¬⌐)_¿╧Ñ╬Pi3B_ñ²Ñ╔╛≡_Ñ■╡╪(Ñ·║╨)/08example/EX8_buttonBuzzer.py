from gpiozero import LED, Button
from signal import pause

buzzer3= LED(27)
button = Button(17)

button.when_pressed = buzzer3.off
button.when_released = buzzer3.on

pause()
