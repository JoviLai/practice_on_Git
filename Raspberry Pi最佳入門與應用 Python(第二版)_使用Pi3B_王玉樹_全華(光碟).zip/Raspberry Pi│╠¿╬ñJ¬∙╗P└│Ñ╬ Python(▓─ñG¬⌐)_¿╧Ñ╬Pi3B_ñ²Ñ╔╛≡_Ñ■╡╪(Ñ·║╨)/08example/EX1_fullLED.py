from gpiozero import RGBLED
from time import sleep
led = RGBLED(red=17, green=27, blue=22)
led.red = 1 
print('RED LED IS ON')
sleep(0.5)
led.color = (0, 0, 0)
sleep(0.5)

led.blue = 1
print('BLUE LED IS ON')
sleep(0.5)
led.color = (0, 0, 0)
sleep(0.5)

led.green = 1
print('GREEN LED IS ON')
sleep(0.5)
led.color = (0, 0, 0)
sleep(0.5)

led.green = 0.5
print('HALF GREEN')
sleep(0.5)
led.color = (0, 0, 0)
sleep(0.5)

led.color = (1, 1, 0)
print('Yellow Color')
sleep(0.5)
led.color = (0, 0, 0)

