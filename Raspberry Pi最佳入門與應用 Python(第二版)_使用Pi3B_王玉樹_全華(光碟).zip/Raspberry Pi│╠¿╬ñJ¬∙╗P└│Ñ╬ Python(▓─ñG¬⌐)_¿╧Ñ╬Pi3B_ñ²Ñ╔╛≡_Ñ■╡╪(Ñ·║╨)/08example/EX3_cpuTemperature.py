from gpiozero import LEDBarGraph, CPUTemperature
from time import sleep
from signal import pause

cpu = CPUTemperature(min_temp=40, max_temp=80)
leds = LEDBarGraph(17, 27, 22, 5, 6, 7, 8, 9, 10, 11, pwm=True)
leds.source = cpu.values

sleep(0.5)
print("GPIO17  = %f"%leds[0].value)
print("GPIO27  = %f"%leds[1].value)
print("GPIO22  = %f"%leds[2].value)
print("GPIO5  = %f"%leds[3].value)
print("GPIO6  = %f"%leds[4].value)
print("GPIO7  = %f"%leds[5].value)
print("GPIO8  = %f"%leds[6].value)
print("GPIO9  = %f"%leds[7].value)
print("GPIO10 = %f"%leds[8].value)
print("GPIO11 = %f"%leds[9].value)

pause()
