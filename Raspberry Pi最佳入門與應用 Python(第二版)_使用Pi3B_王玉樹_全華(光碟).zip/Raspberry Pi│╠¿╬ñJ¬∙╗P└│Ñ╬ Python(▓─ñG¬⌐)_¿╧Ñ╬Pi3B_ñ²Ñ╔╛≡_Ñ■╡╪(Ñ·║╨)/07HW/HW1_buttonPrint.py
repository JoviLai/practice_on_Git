from gpiozero import Button
from signal import pause

def print_hello():
    print("Hello Python!")

def print_goodbye():
    print("Goodbye Python!")

button = Button(2)

button.when_pressed = print_hello
button.when_released = print_goodbye

pause()
