from gpiozero import LED
from time import sleep

red = LED(17)
yellow = LED(27)
green = LED(22)

green.on()
yellow.off()
red.off()

while True:
    print("Green light")
    sleep(10)
    green.off()
    yellow.on()
    print("Yellow light")
    sleep(1)
    yellow.off()
    red.on()
    print("Red light")
    sleep(10)
    green.on()
    yellow.off()
    red.off()

