from gpiozero import PWMLED
from time import sleep

led = PWMLED(17)

while True:
    for n in range(11):
        led.value = n/10        
        print("led.value = %2.2f"%led.value)
        sleep(1)

pause()
