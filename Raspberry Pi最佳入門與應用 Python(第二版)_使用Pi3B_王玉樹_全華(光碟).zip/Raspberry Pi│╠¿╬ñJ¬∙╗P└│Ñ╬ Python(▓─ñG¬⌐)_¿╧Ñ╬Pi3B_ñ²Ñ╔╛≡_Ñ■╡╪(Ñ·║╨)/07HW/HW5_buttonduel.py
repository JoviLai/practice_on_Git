from gpiozero import Button, LED
from time import sleep

led = LED(4)

player_1 = Button(2)
player_2 = Button(3)

while True:
    if player_1.is_pressed:
        print("Player 1 wins!")
        led.on()
        sleep(2)
        break
    if player_2.is_pressed:
        print("Player 2 wins!")
        led.on()
        sleep(3)
        break

led.off()

