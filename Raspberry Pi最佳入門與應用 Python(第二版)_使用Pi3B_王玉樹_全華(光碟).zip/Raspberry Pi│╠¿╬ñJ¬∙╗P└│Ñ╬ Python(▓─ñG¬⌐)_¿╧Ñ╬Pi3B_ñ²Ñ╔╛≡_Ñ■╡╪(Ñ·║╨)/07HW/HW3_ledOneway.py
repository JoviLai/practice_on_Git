from gpiozero import LEDBoard
from time import sleep
from signal import pause

leds = LEDBoard(17, 27, 22, 5)


while True:
    leds.value = (1, 0, 0, 0)
    print("LED1 on")
    sleep(0.2)
    leds.value = (0, 1, 0, 0)
    print("LED2 on")
    sleep(0.2)
    leds.value = (0, 0, 1, 0)
    print("LED3 on")
    sleep(0.2)
    leds.value = (0, 0, 0, 1)
    print("LED4 on")
    sleep(0.2)


pause()
