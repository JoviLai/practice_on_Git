f = open ('testRW.py', 'a')
f.write('Janet', 'Jenny', 'Jennifer')
f.close()
f = open ('testRW.py', 'r')
for line in f:
    print(line,'')
f.close()
