class nameList():

        def __init__(self):
            self.nameId = []

        def orgStds(self):
            self.nameId = ['Robert', 'male', 'S10117357',
                           'Mary', 'female', 'S10117356',
                           'John', 'male', 'S10117358']
    
        def newStd(self, name, gender, Id):
            name1 = self.nameId 
            name1.append(name)
            name1.append(gender)
            name1.append(Id)
            self.nameId = name1
    
        def printList(self):
            for i in self.nameId:
                print(i)

