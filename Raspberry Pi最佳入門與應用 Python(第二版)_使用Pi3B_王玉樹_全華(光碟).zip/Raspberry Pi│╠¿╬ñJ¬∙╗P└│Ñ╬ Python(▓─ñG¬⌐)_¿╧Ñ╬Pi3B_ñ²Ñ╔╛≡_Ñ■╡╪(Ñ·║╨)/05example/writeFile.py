f = open ('testWrite.py', 'w')
f.write('Rober, Mary, John\rJanet, Jenny, Jennifer')
f.close()
f = open ('testWrite.py', 'r')
for line in f:
    print(line,'')
f.close()
