b = 0
for i in range(11):
    i = i + b
    b = i
    print(b, 2*b, 3*b)
