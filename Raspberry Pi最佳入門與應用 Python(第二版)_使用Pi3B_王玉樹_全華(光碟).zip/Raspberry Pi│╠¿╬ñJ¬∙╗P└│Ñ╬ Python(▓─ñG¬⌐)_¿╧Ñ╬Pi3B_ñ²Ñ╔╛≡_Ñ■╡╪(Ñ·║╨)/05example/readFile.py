f = open ('acc.py', 'r')
for line in f:
    print(line, end = '')
f.close()
