def accumulate(n):
    b = 0
    for i in range(n+1):
        i = i + b
        b = i
    return(b)
