f = open ('testRW.py', 'w')
f.write('Robert, ')
f.close()
f = open ('testRW.py', 'r+')
f.write('Mary, John')
for line in f:
    print(line,'')
f.close()
