f = open ('testRW.py', 'w')
nameId = ('Robert', 10117357, 'Mary', 10117356, 'John', 10117358)
f.write(str(nameId))
f.close()
f = open ('testRW.py', 'r')
for line in f:
    print(line,'')
f.close()
