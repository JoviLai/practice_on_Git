class nameList:

#        def __init__(self):
        nameId = []
        def orgStds(nameId):
            f = open ('testRW.py', 'w')
            nameId = ('Robert', 10117357, 'Mary', 10117356, 'John', 10117358)
            f.write(str(nameId))
            f.close()
    
        def newStd(nameId, name, Id):
            f = open ('testRW.py', 'a')
            nameId.append(name, Id) 
            f.close()
    
        def printList(g):
            f = open ('testRW.py', 'r')
            for line in f:
                print(line,'')
            f.close()

