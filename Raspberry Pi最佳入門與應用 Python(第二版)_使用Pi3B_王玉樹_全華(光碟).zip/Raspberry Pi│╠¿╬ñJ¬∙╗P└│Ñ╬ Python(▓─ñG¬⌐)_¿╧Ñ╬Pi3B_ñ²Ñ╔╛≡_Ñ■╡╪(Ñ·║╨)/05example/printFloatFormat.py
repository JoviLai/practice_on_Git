a = 1 / 3
b = 2 / 3
print ('a = {0:.4f}; b = {1:.3f}'.format(a, b))
