import RPi.GPIO as GPIO
import time

LED_PIN = [2,3,5,6,7,8,9,10]
GPIO.setmode(GPIO.BCM)
for i in LED_PIN:
 GPIO.setup(i, GPIO.OUT)
 GPIO.output(i,GPIO.HIGH)

a=1
while a<3:
  print("LOOP %d"%a)

  for i in LED_PIN:
   print ("ON",end=' ')
   GPIO.output(i,GPIO.LOW)
   time.sleep(0.2)
   print ("OFF")
   GPIO.output(i,GPIO.HIGH)

  a+=1
GPIO.cleanup()
