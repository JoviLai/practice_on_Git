import RPi.GPIO as GPIO
import time
LED_PIN_F = [2,3,5,6,7,8,9,10]
LED_PIN_B = [10,9,8,7,6,5,3,2]
GPIO.setmode(GPIO.BCM)
for i in LED_PIN_F:
 GPIO.setup(i, GPIO.OUT)
 GPIO.output(i,GPIO.HIGH)
 
a=1
while a<2:
  print("LOOP %d"%a)
  for i in LED_PIN_F:
   print ("F_ON",end=' ')
   GPIO.output(i,GPIO.LOW)
   time.sleep(0.2)
   print ("F_OFF")
   GPIO.output(i,GPIO.HIGH)
   
  for i in LED_PIN_B:
   print ("B_ON",end=' ')
   GPIO.output(i,GPIO.LOW)
   time.sleep(0.2)
   print ("B_OFF")
   GPIO.output(i,GPIO.HIGH)
  a+=1
GPIO.cleanup()
