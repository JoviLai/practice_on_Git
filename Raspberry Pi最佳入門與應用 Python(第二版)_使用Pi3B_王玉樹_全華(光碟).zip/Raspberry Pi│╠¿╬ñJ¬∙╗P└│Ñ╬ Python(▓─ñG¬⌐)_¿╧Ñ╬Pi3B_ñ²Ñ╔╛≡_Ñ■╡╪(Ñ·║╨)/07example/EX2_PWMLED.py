from gpiozero import PWMLED
from time import sleep

led = PWMLED(2)

while True:
    led.value = 0  
    print("led.value = 0")
    sleep(0.5)
    led.value = 0.25  
    print("led.value = 0.25")
    sleep(0.5)
    led.value = 0.5  
    print("led.value = 0.5")
    sleep(0.5)
    led.value = 0.75  
    print("led.value = 0.75")
    sleep(0.5)
    led.value = 1
    print("led.value = 1")
    sleep(0.5)
pause()
