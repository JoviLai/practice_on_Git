from gpiozero import LEDBoard
from signal import pause
from time import sleep

pwmLeds = LEDBoard(17, 27, 22, 5, pwm = True)

pwmLeds.value = (0, 0.25, 0.5, 1.0)
sleep(5)
pwmLeds.value = (0, 0, 0, 0)

pause()
