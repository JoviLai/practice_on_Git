from gpiozero import LED
from time import sleep

relay = LED(2)

a = 5
while a>0:
    print ("Relay Off",end=' ')
    relay.off()
    sleep(0.2)
    print ("Relay On")
    relay.on()
    sleep(0.2)
    a-=1





