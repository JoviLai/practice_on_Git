from gpiozero import LED
from time import sleep

Relay_in = LED(2)

a = 5
while a>0:
    print ("Solenoid Off",end=' ')
    Relay_in.on()
    sleep(2)
    print ("Solenoid On")
    Relay_in.off()
    sleep(2)
    a-=1
