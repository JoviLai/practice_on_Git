from gpiozero import LEDBoard
from time import sleep
from signal import pause

leds = LEDBoard(17, 27, 22, 5)

print("HIGH",end = ' ')
leds.on()
sleep(2)
print("LOW")
leds.off()
sleep(2)
print("LED1 & LED3 ON")
leds.value = (1, 0, 1, 0)
sleep(2)
print("BLINK")
leds.blink()

pause()
