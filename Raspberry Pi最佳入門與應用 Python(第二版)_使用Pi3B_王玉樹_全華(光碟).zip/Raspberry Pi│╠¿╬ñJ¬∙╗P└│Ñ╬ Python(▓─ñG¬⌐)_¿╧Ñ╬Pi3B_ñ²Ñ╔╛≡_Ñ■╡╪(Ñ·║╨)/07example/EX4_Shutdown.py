from gpiozero import LED, Button
from subprocess import check_call
from signal import pause

BTN_FOR_LED = 2
LED_PIN = 17
led = LED(LED_PIN) 
led.off()

def shutdown():
    check_call(['sudo', 'poweroff'])
  
btnForLed = Button(BTN_FOR_LED)
btnForLed.when_pressed = led.on
btnForLed.when_released = led.off

shutdown_btn = Button(3, hold_time=2)
shutdown_btn.when_held = shutdown

pause()
