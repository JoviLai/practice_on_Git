from gpiozero import LED
from time import sleep

red = LED(2)

a = 5
while a>0:
    print ("LOW",end=' ')
    red.off()
    sleep(0.2)
    print ("HIGH")
    red.on()
    sleep(0.2)
    a-=1





