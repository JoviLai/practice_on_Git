from gpiozero import LEDBoard
from time import sleep
from signal import pause

dcMotors = LEDBoard(5, 6)

print("Clockwise")
dcMotors.value = (1, 0)
sleep(5)
print("STOP")
dcMotors.value = (0, 0)
sleep(1)
print("Counterclockwise")
dcMotors.value = (0, 1)
sleep(5)
print("STOP")
dcMotors.value = (0, 0)

pause()
