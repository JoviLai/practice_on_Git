from gpiozero import PingServer, LED
from signal import pause
from time import sleep

STU = PingServer('www.stu.edu.tw')
led = LED(17)

while True:
    led.value = STU.value
    if (led.value):
        print("www.stu.edu.tw is online!")
    sleep(60)

pause()
