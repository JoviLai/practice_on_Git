from bluedot import BlueDot
from gpiozero import Robot, LEDBoard
from signal import pause
from time import sleep

bd = BlueDot()
dcMotor = LEDBoard(5, 6)

def move(pos):
    if pos.top:
            dcMotor.value = (0, 0)
            print('STOP')
    elif pos.bottom:
            dcMotor.value = (0, 0)
            print('STOP')
    elif pos.left:
            dcMotor.value = (1, 0)
            print('Clockwise')
    elif pos.right:
            dcMotor.value = (0, 1)
            print('Counterclockwise')
bd.when_pressed = move
bd.when_moved = move
       
pause()
