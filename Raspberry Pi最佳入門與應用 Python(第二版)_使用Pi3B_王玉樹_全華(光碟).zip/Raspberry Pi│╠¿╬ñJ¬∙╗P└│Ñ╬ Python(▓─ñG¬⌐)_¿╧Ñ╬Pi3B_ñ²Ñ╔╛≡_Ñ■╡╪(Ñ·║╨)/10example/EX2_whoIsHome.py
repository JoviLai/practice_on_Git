from gpiozero import PingServer, LEDBoard
from gpiozero.tools import negated
from signal import pause

status = LEDBoard(
    studentA=LEDBoard(red=17, green=27),
    studentB=LEDBoard(red=22, green=5),
    )
statuses = {
    PingServer('192.168.0.3'): status.studentA,
    PingServer('192.168.0.4'): status.studentB,
    }

for server, leds in statuses.items():
    leds.green.source = server.values
    leds.red.source = negated(leds.green.values)
    leds.green.source_delay = 60

pause()
