from gpiozero import Button
import pygame.mixer
from pygame.mixer import Sound
from signal import pause

pygame.mixer.init()

button_sounds = {

    Button(2): Sound("ambi_choir.wav"),
    Button(3): Sound("ambi_dark_woosh.wav"),
}

for button, sound in button_sounds.items():
    button.when_pressed = sound.play

pause()

