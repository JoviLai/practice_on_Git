from gpiozero import TimeOfDay, Energenie, LED
from datetime import time
from signal import pause

NST1 = int(input("Input Start Time. for example,\
14 means 2 o'clock in the afternoon: "))
NST2 = int(input("Input Stop Time: "))

led = LED(17)
startTime = NST1 - 8
stopTime = NST2 -8

timeSet = TimeOfDay(time(startTime), time(stopTime))

led.source = timeSet.values

pause()
