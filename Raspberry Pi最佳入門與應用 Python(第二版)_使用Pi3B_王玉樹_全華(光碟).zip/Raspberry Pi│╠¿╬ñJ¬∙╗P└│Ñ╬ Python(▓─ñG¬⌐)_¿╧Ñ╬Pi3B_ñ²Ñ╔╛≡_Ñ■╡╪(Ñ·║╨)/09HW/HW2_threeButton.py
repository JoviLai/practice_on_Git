from gpiozero import LED, Button
from gpiozero.pins.pigpio import PiGPIOFactory
from gpiozero.tools import all_values
from signal import pause

factory1 = PiGPIOFactory(host='192.168.0.3')
factory2 = PiGPIOFactory(host='192.168.0.4')
factory3 = PiGPIOFactory(host='192.168.0.5')

led = LED(2)
button1 = Button(2, pin_factory=factory1)
button2 = Button(2, pin_factory=factory2)
button3 = Button(2, pin_factory=factory3)

if (button1.wait_for_press() and button2.wait_for_press() and button3.wait_for_press()):
    print("Button1, button2 and button3 are pressed!!!")
    print("Local LED(GPIO2) should be on!!!")

led.source = all_values(button1.values, button2.values, button3.values)

    
pause()
