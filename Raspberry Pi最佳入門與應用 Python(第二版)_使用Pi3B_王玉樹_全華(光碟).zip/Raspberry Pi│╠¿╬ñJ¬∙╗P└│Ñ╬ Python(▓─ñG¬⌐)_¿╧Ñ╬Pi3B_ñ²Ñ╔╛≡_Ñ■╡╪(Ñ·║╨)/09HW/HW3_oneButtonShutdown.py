from gpiozero import LED, Button
from gpiozero.pins.pigpio import PiGPIOFactory
from subprocess import check_call
from time import sleep
from signal import pause

def shutdown():
    check_call(['sudo', 'poweroff'])
    
factory = PiGPIOFactory(host='192.168.0.4')
button = Button(2, hold_time=5, pin_factory=factory)
shutdown_btn = button
shutdown_btn.when_held = shutdown
      
pause()
