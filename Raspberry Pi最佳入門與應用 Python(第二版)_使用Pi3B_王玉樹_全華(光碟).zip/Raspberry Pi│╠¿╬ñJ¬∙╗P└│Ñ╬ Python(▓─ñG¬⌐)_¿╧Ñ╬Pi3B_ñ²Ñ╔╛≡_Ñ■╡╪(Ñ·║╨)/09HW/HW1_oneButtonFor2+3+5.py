from gpiozero import LED, Button, LEDBoard
from gpiozero.pins.pigpio import PiGPIOFactory
from time import sleep
from signal import pause

factory = PiGPIOFactory(host='192.168.0.3')

button = Button(2)
button.wait_for_press()

print("Button is pressed and command is sent!!!")
print("LEDs connected to GPIO2, GPIO3 and GPIO5 of 192.168.0.3 are on!!!")    

leds = LEDBoard(2, 3, 5, pin_factory=factory)
for i in leds:
    i.source = button.values

pause()
