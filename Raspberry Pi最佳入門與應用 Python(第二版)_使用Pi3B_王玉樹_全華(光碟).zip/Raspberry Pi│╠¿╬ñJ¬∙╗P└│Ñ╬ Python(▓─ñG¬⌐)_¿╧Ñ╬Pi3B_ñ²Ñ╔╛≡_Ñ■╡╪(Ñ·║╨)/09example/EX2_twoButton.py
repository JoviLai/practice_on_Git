from gpiozero import LED, Button
from gpiozero.pins.pigpio import PiGPIOFactory
from gpiozero.tools import all_values
from signal import pause

factory1 = PiGPIOFactory(host='192.168.0.3')
factory2 = PiGPIOFactory(host='192.168.0.4')

led = LED(27)
button1 = Button(17, pin_factory=factory1)
button2 = Button(17, pin_factory=factory2)

if (button1.wait_for_press() and button2.wait_for_press()):
    print("both button1 and button2 are pressed!!!")
    print("Local LED(GPIO27) should be on!!!")

led.source = all_values(button1.values, button2.values)
