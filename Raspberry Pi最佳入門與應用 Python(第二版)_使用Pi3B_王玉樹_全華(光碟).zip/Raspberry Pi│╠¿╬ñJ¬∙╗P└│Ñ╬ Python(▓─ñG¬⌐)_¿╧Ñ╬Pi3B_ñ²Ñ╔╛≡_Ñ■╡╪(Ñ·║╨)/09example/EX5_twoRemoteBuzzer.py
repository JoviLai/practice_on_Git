from gpiozero import LEDBoard, MotionSensor, Buzzer, Button
from gpiozero.pins.pigpio import PiGPIOFactory
from signal import pause

ips = ['192.168.0.3', '192.168.0.4']

remotes = [PiGPIOFactory(host=ip) for ip in ips]

button = Button(17) 
buzzers = [Buzzer(17, pin_factory=r) for r in remotes]

for buzzer in buzzers:
    buzzer.source = button.values

pause()
