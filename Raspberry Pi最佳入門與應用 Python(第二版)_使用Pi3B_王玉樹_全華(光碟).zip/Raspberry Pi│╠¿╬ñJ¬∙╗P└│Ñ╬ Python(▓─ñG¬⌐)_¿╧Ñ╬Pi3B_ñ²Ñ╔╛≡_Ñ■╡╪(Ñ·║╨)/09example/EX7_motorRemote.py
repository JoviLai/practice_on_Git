from gpiozero import Button, LEDBoard
from gpiozero.pins.pigpio import PiGPIOFactory
from signal import pause
from time import sleep

factory = PiGPIOFactory(host='192.168.128.64')
rMotor = LEDBoard(5, 6, pin_factory=factory )
button = Button(2)
button.wait_for_press()

rMotor.value = (1, 0)
print("Clockwise")
sleep(5)
rMotor.value = (0, 0)
print("STOP")
sleep(1)
rMotor.value = (0, 1)
print("Counterclockwise")
sleep(5)
rMotor.value = (0, 0)
print("STOP")
pause()
