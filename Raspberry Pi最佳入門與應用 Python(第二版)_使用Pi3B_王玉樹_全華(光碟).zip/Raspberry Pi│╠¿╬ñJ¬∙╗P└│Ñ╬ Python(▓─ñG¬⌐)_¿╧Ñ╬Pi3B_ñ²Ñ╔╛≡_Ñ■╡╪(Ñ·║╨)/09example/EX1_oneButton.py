from gpiozero import Button, LED
from gpiozero.pins.pigpio import PiGPIOFactory
from signal import pause

factory = PiGPIOFactory(host='192.168.0.3')

button = Button(17)
button.wait_for_press()
print("Button is pressed and command is sent!!!")
print("LED connected to GPIO2 of 192.168.0.3 is on!!!")    

led = LED(27, pin_factory=factory)
led.source = button.values


