from gpiozero import LEDBoard, MotionSensor
from gpiozero.pins.pigpio import PiGPIOFactory
from signal import pause

ips = ['192.168.0.3', '192.168.0.6']
remotes = [PiGPIOFactory(host=ip) for ip in ips]

leds = LEDBoard(17, 27)  
sensors = [MotionSensor(17, pin_factory=r) for r in remotes]  
for led, sensor in zip(leds, sensors):
    sensor.when_no_motion = led.off
    sensor.when_motion = led.on

pause()
