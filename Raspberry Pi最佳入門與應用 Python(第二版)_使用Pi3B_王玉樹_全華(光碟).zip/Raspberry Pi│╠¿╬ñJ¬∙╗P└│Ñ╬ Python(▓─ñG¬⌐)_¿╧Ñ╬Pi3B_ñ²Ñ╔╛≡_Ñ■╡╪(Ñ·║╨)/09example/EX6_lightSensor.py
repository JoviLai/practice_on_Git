from gpiozero import LightSensor, LED
from gpiozero.pins.pigpio import PiGPIOFactory
from signal import pause

factory = PiGPIOFactory(host='192.168.0.3')

sensor = LightSensor(17)    

led = LED(17, pin_factory=factory)

sensor.when_dark = led.on 
sensor.when_light = led.off

pause()
