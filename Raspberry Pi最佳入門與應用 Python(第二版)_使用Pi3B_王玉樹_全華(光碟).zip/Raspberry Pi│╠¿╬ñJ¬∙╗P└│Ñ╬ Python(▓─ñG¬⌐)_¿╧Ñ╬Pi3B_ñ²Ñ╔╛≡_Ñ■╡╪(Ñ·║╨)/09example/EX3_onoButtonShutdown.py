from gpiozero import LED, Button
from gpiozero.pins.pigpio import PiGPIOFactory
from subprocess import check_call
from time import sleep
from signal import pause

def shutdown():
    check_call(['sudo', 'poweroff'])
    
factory = PiGPIOFactory(host='192.168.0.4')
button = Button(2, pin_factory=factory)

if (button.wait_for_press()):
    print("System will be shut down in 60 seconds!!!")
    sleep(60)
    shutdown()
      
pause()
