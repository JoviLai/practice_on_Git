from gpiozero import Button
from picamera import PiCamera
from datetime import datetime
from signal import pause
from time import sleep

button = Button(2)
camera = PiCamera()

def capture():
    datetime1 = datetime.now().isoformat()
    camera.capture('/home/pi/10HW/%s.jpg' % datetime1)

#button.when_pressed = capture
while True:
    if button.is_pressed:
        capture()
        print("Picture is taken")
        sleep(0.5)
pause()
