from gpiozero import PingServer, LED
from signal import pause
from time import sleep

STU = PingServer('www.stu.edu.tw')
led = LED(2)

while True:
    led.value = STU.value
    if (led.value):
        print("www.stu.edu.tw is online!")
    if not(led.value):
        print("www.stu.edu.tw is offline!")
    sleep(60)

