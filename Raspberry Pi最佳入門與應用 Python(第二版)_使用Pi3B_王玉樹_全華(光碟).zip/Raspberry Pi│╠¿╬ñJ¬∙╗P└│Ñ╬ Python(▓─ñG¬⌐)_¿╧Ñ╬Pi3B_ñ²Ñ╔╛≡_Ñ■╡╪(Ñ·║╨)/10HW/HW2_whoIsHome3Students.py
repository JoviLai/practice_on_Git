from gpiozero import PingServer, LEDBoard
from gpiozero.tools import negated
from signal import pause

status = LEDBoard(
    studentA=LEDBoard(red=2, green=3),
    studentB=LEDBoard(red=4, green=5),
    studentC=LEDBoard(red=6, green=7),
    
)

statuses = {
    PingServer('192.168.0.3'): status.studentA,
    PingServer('192.168.0.4'): status.studentB,
    PingServer('192.168.0.5'): status.studentC,

}

for server, leds in statuses.items():
    leds.green.source = server.values
    leds.green.source_delay = 60
    leds.red.source = negated(leds.green.values)

pause()
