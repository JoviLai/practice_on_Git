from gpiozero import TimeOfDay, LED
from gpiozero.pins.pigpio import PiGPIOFactory
from datetime import time
from signal import pause
from time import sleep

NST1 = int(input("Input Start Time. for example,\
14 means 2 o'clock in the afternoon: "))
NST2 = int(input("Input Stop Time: "))

led = LED(2)
startTime = NST1 - 8
stopTime = NST2 -8

timeSet = TimeOfDay(time(startTime), time(stopTime))

#led.source = timeSet.values
while True:
    led.value = timeSet.value
    if (led.value):
        print("LED is on!")
    if not(led.value):
        print("LED is off!")
    sleep(60)
    
pause()
