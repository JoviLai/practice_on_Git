b = 0
for i in range(20):
    i = i + b
    b = i
    print('{0:3d} {1:3d} {2:4d}'.format(b, 2*b, 3*b))
