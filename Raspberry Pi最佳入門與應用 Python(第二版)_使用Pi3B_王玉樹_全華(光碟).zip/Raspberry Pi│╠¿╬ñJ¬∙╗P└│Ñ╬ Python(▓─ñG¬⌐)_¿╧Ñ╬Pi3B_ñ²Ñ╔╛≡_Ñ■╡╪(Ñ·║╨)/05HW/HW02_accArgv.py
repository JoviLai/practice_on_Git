def accumulate(n):
    b = 0
    for i in range(n+1):
        i = i + b
        b = i
    print(b)
if __name__ == "__main__":
    import sys
    accumulate(int(sys.argv[1]))
