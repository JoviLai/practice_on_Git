from gpiozero import LEDBarGraph, CPUTemperature
from time import sleep
from signal import pause

cpu = CPUTemperature(min_temp=40, max_temp=100)
leds = LEDBarGraph(17, 27, 22, 5, 6, 7, 8, 9, 10, 11, pwm=True)
leds.source = cpu.values

sleep(0.5)

for i in leds:
    print(i.value)

pause()
