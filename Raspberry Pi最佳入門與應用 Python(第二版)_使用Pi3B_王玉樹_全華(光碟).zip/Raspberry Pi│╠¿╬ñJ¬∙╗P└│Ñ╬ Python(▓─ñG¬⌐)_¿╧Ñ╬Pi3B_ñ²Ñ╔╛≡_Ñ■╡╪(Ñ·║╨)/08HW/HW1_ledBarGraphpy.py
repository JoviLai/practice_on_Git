from gpiozero import LEDBarGraph
from time import sleep

graph = LEDBarGraph(17, 27, 22, 5, 6, 7, 8, 9, 10, 11, pwm=True)

graph.value = -2/10
print("-2/10 = (0, 0, 0, 0, 0, 0, 0, 0, 1, 1)")
sleep(0.5)
graph.value = 2/10  
print("2/10 = (1, 1, 0, 0, 0, 0, 0, 0, 0, 0)")
sleep(0.5)
