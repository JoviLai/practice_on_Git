from django.contrib import admin
from newsapp.models import NewsUnit

admin.site.register(NewsUnit)
