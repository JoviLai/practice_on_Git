from django.apps import AppConfig


class StudentsappConfig(AppConfig):
    name = 'studentsapp'
